from werkzeug.security import generate_password_hash
from flask import Flask, render_template, request, flash, redirect, url_for
from forms.register_form import RegisterForm
from data import db_session
from data.jobs import Jobs
from data.users import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'flask-sqlalchemy'
db_sess = None


@app.route('/')
def jobs_list():
    global db_sess

    jobs = db_sess.query(Jobs).all()

    return render_template(
        "jobs.html",
        jobs=jobs
    )


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        if db_sess.query(User).filter(User.email == form.email.data).first():
            flash("Пользователь с таким email уже существует")

            return render_template(
                'register.html',
                title='Регистрация',
                form=form
            )

        user = User(
            surname=form.surname.data,
            name=form.name.data,
            age=form.age.data,
            position=form.position.data,
            speciality=form.speciality.data,
            address=form.address.data,
            email=form.email.data,
            hashed_password=generate_password_hash(form.password.data)
        )
        db_sess.add(user)
        db_sess.commit()

        return redirect('/')

    return render_template(
        'register.html',
        title='Регистрация',
        form=form
    )


def main() -> None:
    db_session.global_init("db/mars_users.db")

    global db_sess
    db_sess = db_session.create_session()

    app.run(host='0.0.0.0', port=5000, debug=True)


if __name__ == '__main__':
    main()
